# -*- coding: utf-8 -*-


#Factor Vs Numeric

import pandas as pd
#from categorical_1 import GetGroup_Cat_Num

def GetGroup_Cat_Num(train, colCat,colNum, iRoundCutoffDigit = 2, bConvertToLower = False, nSelectTopN = 10):
    # Select only required column
    df = pd.DataFrame(train[[colCat, colNum]])

    # Convert to lower if required
    if bConvertToLower:
        df[colCat] = df[colCat].str.lower()

    # Take mean of Numeric variable grouped by category variable. Sort Desecnding
    df = df.groupby(colCat).mean().reset_index()
    df = df.sort_values(colNum, ascending = False)

    # Take top N
    df = df.head(min(len(df), nSelectTopN))

    return(df)  # GetGroup_Cat_Num

def Desc_FactorVsNumeric (data, listNumericFeatures1, listCategoricalFeatures1, filePdf = "", folderImageDescriptive = ""):

    #Importing list of packages
    import matplotlib.pyplot as plt
    plt.rcParams['figure.figsize'] = (16.0, 12.0)
    plt.style.use('ggplot')
    from matplotlib.backends.backend_pdf import PdfPages
    import datetime             
         
    filePdf = filePdf + "_" +  "Bivariate_FactorVsNumeric.pdf"    

    pdf = PdfPages(folderImageDescriptive + filePdf + str(datetime.datetime.now().strftime("%Y%m%d-%H%M%S")) + ".pdf")

    for i in range(0, len(listCategoricalFeatures1), 1):  # i =0
#        print(i)
        Column2 = listCategoricalFeatures1[i]       
        
        for j in range(0, len(listNumericFeatures1), 2):
#           print(j)            
            Column1 = listNumericFeatures1[j]
#            if(j != len(listNumericFeatures1) - 1):
#                Column3 = listNumericFeatures1[j + 1]

            fig = plt.figure()
            ax = fig.add_subplot(111) # Create matplotlib axes            
            
            plt.suptitle("Distribution of "+ Column2 + " vs " + Column1 + " vs " , fontsize=16, color= 'black')
            df = GetGroup_Cat_Num(data, Column2,Column1)
            df= df.reset_index(drop= True)
            width = 0.4
            df.plot.bar(x=Column2, y=Column1, width= width,ax = ax, color= "red",position=1)
            plt.ylabel("Average of " + Column1, size=12)
            plt.ylim(0,df[Column1].max()*1.1)
            
#            ax2 = ax.twinx()
#            df.plot.bar(x=Column2, y=Column3,width = width, ax = ax2, color= "blue",position=0)
#            plt.ylabel("Average of " + Column3, size=12)
#            plt.xlabel(Column2, size=12)
#            plt.xticks(rotation= 45)
#            plt.ylim(0,df[Column3].max()*1.1)
#            ax.legend(loc='upper left')
            fig.tight_layout()
            pdf.savefig()
            plt.close()
            plt.gcf().clear()
                    
    pdf.close()
    
    
    
survey = pd.read_csv("C:\\Users\\mxc1185\\Desktop\\survey_wordcloud.csv",encoding="windows-1252")
Desc_FactorVsNumeric(survey,["Wave Number"],["Category "],"Survey")
#Function Ends    


#path= r'D:\INFY_BACKUP\Projects\Analytics\Utility\L48 LATEST'
#import os
#os.chdir(path)
#print(os.getcwd())
#
#import pandas as pd
#
#MergedFile = pd.read_csv('Input/FinalFile.csv',low_memory=False)
#
#MergedFile["PROD_DAYS"]= MergedFile["PROD_DAYS"].astype(str)           
#MergedFile["PROD_DAYS"] = MergedFile["PROD_DAYS"].str[0:2]   
##MergedFile.Prod_Days_Test.head()
#
#MergedFile = MergedFile.rename(columns={'%Accuracy': 'AccuracyPercentage'})
#
#MergedFile = MergedFile.convert_objects(convert_numeric=True)
#
#Merged = MergedFile[(MergedFile.AccuracyPercentage >= -30) & (MergedFile.AccuracyPercentage <= 30)]
#
#listNumericFeatures1 = ["TOTAL_GASVOL","AVG_METER_TEMPERATURE","TOTAL_PRODUCTIONTIME",
#                        "TOTAL_HOURS_DOWN","PROD_DAYS","WELL_AGE_YEARS",
#                        "WELL_AGE_MONTHS","TOTAL_WELLCAPABILITY_GAS","EIQ_KB_ELEV","EIQ_GR_ELEV","EIQ_TOTAL_DEPTH",
#                        "Diff_TotalGasVol","Rate_TotalGasVol","Cumulative_TotalGasVol"]
#
#listCategoricalFeatures1 = ['ASSET', 'NAME','EIQ_PROFILE_TYPE']      
#
#Desc_FactorVsNumeric (Merged, listNumericFeatures1, listCategoricalFeatures1)

